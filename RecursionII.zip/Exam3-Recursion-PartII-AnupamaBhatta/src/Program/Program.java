package Program;

/**
 * Name: Anupama Bhatta
 * Date: 04/17/2018
 * Description: Java application that allows searching for files and rename files in batches.
 */

public class Program {
    public static void main(String[] args) {
    
          new UI_Form().setVisible(true);
    }
}
